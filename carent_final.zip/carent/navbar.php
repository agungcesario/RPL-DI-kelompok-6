        <nav class="navbar navbar-light bg-bdnavy text-white justify-content-between">
            <a class="navbar-brand" style="font-family:Ripeye;">CaRent</a>
            
            <span class="navbar-text">
                <a href="home.php" class="mr-2 text-white">HOME</abs>
                <a href="login.php" class="mr-2 text-white">LOGIN</a>
                <a href="register.php" class="mr-2 text-white">REGISTER</a>
            </span>
        </nav>