<!-- font-weight-bold -->
<a href="lihatdatarental.php" class="btn bg-lightblue text-dark w-100 m-0 <?php echo $lihatdatarental ?? "";?>">Lihat Data Rental</a>
<a href="editdatamobil.php" class="btn bg-lightblue text-dark w-100 m-0 <?php echo $editdatamobil ?? ""; ?>">Edit Data Mobil</a>
<a href="editdatapaketkopling.php" class="btn bg-lightblue text-dark w-100 m-0 <?php echo $editdatapaketkopling ?? ""; ?>">Edit Data Paket Kopling</a>
<a href="editdatapaketmatic.php" class="btn bg-lightblue text-dark w-100 m-0 <?php echo $editdatapaketmatic ?? ""; ?>">Edit Data Paket Matic</a>
<a href="editdatasupir.php" class="btn bg-lightblue text-dark w-100 m-0 <?php echo $editdatasupir ?? ""; ?>">Edit Data Supir</a>
<a href="buktipembayaran.php" class="btn bg-lightblue text-dark w-100 m-0 <?php echo $buktipembayaran ?? ""; ?>">Bukti Pembayaran Customer</a>
<a href="metodepembayaranadmin.php" class="btn bg-lightblue text-dark w-100 m-0 <?php echo $metodepembayaranadmin ?? ""; ?>">Metode Pembayaran</a>